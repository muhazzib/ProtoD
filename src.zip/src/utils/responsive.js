import { createResponsiveStyle } from 'styled-components'

export const ResponsiveStyle = createResponsiveStyle`

.content strong{
    color: #345fa8;
  }



`
export default ResponsiveStyle
