module.exports = {
  langs: ['en-US', 'de'],
  defaultLangKey: 'en-US',
}
