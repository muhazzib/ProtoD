module.exports = {
  selectLanguage: 'Select your language',
}
