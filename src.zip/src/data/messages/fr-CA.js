module.exports = {
  selectLanguage: 'French',
}
