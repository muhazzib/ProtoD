module.exports = {
  langs: ['en-US', 'fr-CA'],
  defaultLangKey: 'en-US',
}
